# SPDX-FileCopyrightText: 2025-present zerubabeldinsa <zerubabel.dinsa@gmail.com>
#
# SPDX-License-Identifier: MIT

from .portfolio_construction.return_allocations.efficient_frontier import risk_return
